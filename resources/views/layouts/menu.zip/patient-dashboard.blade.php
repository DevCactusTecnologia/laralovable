
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-flex align-items-center justify-content-between">
            <h4 class="mb-0 font-size-18">{{ __('Dashboard') }}</h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item active">Bem-vindo ao {{ config('app.name') }} Dashboard</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-xl-4">
        <div class="card overflow-hidden">
            <div class="bg-soft-primary">
                <div class="row">
                    <div class="col-7">
                        <div class="text-primary p-3">
                            <h5 class="text-primary">{{ __('Bem vindo de volta!') }}</h5>
                            <p>{{ config('app.name') }} {{ __('Dashboard') }}</p>
                        </div>
                    </div>
                    <div class="col-5 align-self-end">
                        <img src="{{ URL::asset('assets/images/profile-img.png') }}" alt="" class="img-fluid">
                    </div>
                </div>
            </div>
            <div class="card-body pt-0">
                <div class="row">
                    <div class="col-sm-5">
                        <div class="avatar-md profile-user-wid mb-4">
                            <img src="@if ($user->profile_photo != null){{ URL::asset('storage/images/users/' . $user->profile_photo) }}@else{{ URL::asset('assets/images/users/noImage.png') }}@endif" class="img-thumbnail rounded-circle">
                        </div>
                        <h5 class="font-size-15">{{ $user->first_name }}</h5>
                        <p class="text-muted mb-0 text-truncate">{{ __('Paciente') }}</p>
                    </div>
                    <div class="col-sm-7">
                        <div class="pt-4">
                            <div class="row">
                                <div class="col-12">
                                    <h5 class="font-size-12">{{ __('Último Login:') }}</h5>
                                    <p class="text-muted mb-0">
                                        {{ date('d/m/Y H:i:s', strtotime($user->last_login)) }}
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       
    </div>
    <div class="col-xl-8">
        <div class="row">
            <div class="col-md-4">
                <div class="card mini-stats-wid">
                    <div class="card-body">
                        <div class="media">
                            <div class="media-body">
                                <p class="text-muted font-weight-medium">{{ __('Atendimentos') }}</p>
                                <h4 class="mb-1">{{ number_format($data['total_appointment']) }}</h4>
                            </div>
                            <div class="mini-stat-icon avatar-sm rounded-circle bg-primary align-self-center">
                                <span class="avatar-title">
                                    <i class="bx bxs-calendar-check font-size-24"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card mini-stats-wid">
                    <div class="card-body">
                        <div class="media">
                            @if (session()->has('page_limit'))
                                @php
                                    $per_page = session()->get('page_limit');
                                @endphp
                            @else
                                @php
                                    $per_page = Config::get('app.page_limit');
                                @endphp
                            @endif
                            <div class="media-body">
                                <p class="text-muted font-weight-medium">{{ __('Exibir itens por página') }}</p>
                                <button
                                    class="btn  {{ $per_page == 10 ? 'btn-primary' : 'btn-info' }}  btn-sm mr-2 per-page-items  mb-md-1"
                                    data-page="10">10</button>
                                <button
                                    class="btn  {{ $per_page == 25 ? 'btn-primary' : 'btn-info' }}  btn-sm mr-2 per-page-items  mb-md-1"
                                    data-page="25">25</button>
                                <button
                                    class="btn  {{ $per_page == 50 ? 'btn-primary' : 'btn-info' }}  btn-sm mr-2 per-page-items  mb-md-1"
                                    data-page="50">50</button>
                                <button
                                    class="btn  {{ $per_page == 100 ? 'btn-primary' : 'btn-info' }}  btn-sm mr-2 per-page-items  mb-md-1"
                                    data-page="100">100</button>
                            </div>
                            <div class="avatar-sm rounded-circle bg-primary align-self-center mini-stat-icon">
                                <span class="avatar-title rounded-circle bg-primary">
                                    <i class="bx bx-book-open font-size-24"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- end row -->

        <div class="card">
            <div class="card-body">
                <h4 class="card-title mb-4">{{ __('Últimos Atendimentos') }}</h4>
                <div class="table-responsive">
                    <table class="table table-centered table-nowrap mb-0">
                        <thead class="thead-light">
                            <tr>
                                <th>{{ __('Nº') }}</th>
                                <th>{{ __('Nome do Médico') }}</th>
                                <th>{{ __('Data') }}</th>
                                <th>{{ __('Status') }}</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($appointments as $item)
                                <tr>
                                    <td>{{ $loop->index + 1 }}</td>
                                    <td>{{ $item->doctor->first_name }} {{ $item->doctor->last_name }}</td>
                                    <td>{{ $item->appointment_date }}</td>
                                    <td>
                                        @if ($item->status == 0)
                                            <span class="badge badge-warning">Pendente</span>
                                        @elseif ($item->status == 1 )
                                            <span class="badge badge-success">Finalizado</span>
                                        @elseif ($item->status == 2 )
                                            <span class="badge badge-danger">Cancelado</span>
                                        @endif
                                    </td>
                                    <td>
                                        @if ($item->status == 1 )
                                        <a href="{{ route('appointments.result.print', $item->id) }}" class="btn btn-success text-white" target="_blank">
                                            <i class="mdi mdi-printer font-size-13 align-middle"></i>
                                        </a>
                                        <a href="{{ route('appointments.result.pdf', $item->id) }}" class="btn btn-danger text-white" target="_blank">
                                            PDF
                                        </a>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                <!-- end table-responsive -->
            </div>
        </div>
    </div>
</div>
