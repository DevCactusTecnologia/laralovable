
<div class="row">
    <div class="col-12">
        <div class="page-title-box d-flex align-items-center justify-content-between">
            <h4 class="mb-0 font-size-18">Dashboard</h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item active">Bem-vindo ao {{ config('app.name') }} Dashboard</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-xl-4">
        <div class="card overflow-hidden">
            <div class="bg-soft-primary">
                <div class="row">
                    <div class="col-7">
                        <div class="text-primary p-3">
                            <h5 class="text-primary">Bem vindo de volta!</h5>
                            <p>{{ config('app.name') }} Dashboard</p>
                        </div>
                    </div>
                    <div class="col-5 align-self-end">
                        <img src="{{ asset('assets/images/profile-img.png') }}" alt="" class="img-fluid">
                    </div>
                </div>
            </div>
            <div class="card-body pt-0">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="avatar-md profile-user-wid mb-4">
                            <img src="@if ($user->profile_photo != null){{ asset('storage/images/users/' . $user->profile_photo) }}@else{{ asset('assets/images/users/noImage.png') }}@endif" class="img-thumbnail rounded-circle">
                        </div>
                        <h5 class="font-size-15 mb-1">{{ $user->first_name }} {{ $user->last_name }}</h5>
                        <p class="text-muted mb-0 text-truncate">Analista</p>
                    </div>
                </div>
            </div>
        </div>
       
        {{-- CAMPANHA --}}
        <div class="bg-primary" style="border-radius: 5px;">
            <img src="{{ asset($campaignCurrent->url_image) }}" width="100%" height="140px" alt="{{ $campaignCurrent->name }}">
        </div>

    </div>
    <div class="col-xl-8">
        <div class="row">
            <div class="col-md-4">
                <div class="card mini-stats-wid">
                    <div class="card-body">
                        <div class="media">
                            <div class="media-body">
                                <p class="text-muted font-weight-medium">Atendimentos Hoje</p>
                                <div class="mb-0 font-weight-medium font-size-24">
                                    <h4 class="mb-0">{{ $today_appointment_total }}</h4>
                                </div>
                            </div>
                            <div class="mini-stat-icon avatar-sm rounded-circle bg-primary align-self-center">
                                <span class="avatar-title">
                                    <i class="bx bx-calendar-check font-size-24"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card mini-stats-wid">
                    <div class="card-body">
                        <div class="media">
                            <div class="media-body">
                                <p class="text-muted font-weight-medium">Atendimentos Pendentes</p>
                                <h4 class="mb-0">{{ $pending_appointment_total }}</h4>
                            </div>
                            <div class="avatar-sm rounded-circle bg-primary align-self-center mini-stat-icon">
                                <span class="avatar-title rounded-circle bg-primary">
                                    <i class="bx bx-calendar-event font-size-24"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card mini-stats-wid">
                    <div class="card-body">
                        <div class="media">
                            <div class="media-body">
                                <p class="text-muted font-weight-medium">Pacientes Agendados</p>
                                <div class="mb-0 font-weight-medium font-size-24">
                                    <h4 class="mb-0">{{ $upcoming_appointment_total }}</h4>
                                </div>
                            </div>
                            <div class="avatar-sm rounded-circle bg-primary align-self-center mini-stat-icon">
                                <span class="avatar-title rounded-circle bg-primary">
                                    <i class="bx bx-purchase-tag-alt font-size-24"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="card">
            <div class="card-body">
                <div class="d-md-flex justify-content-md-between align-items-center mb-3">
                    <h4 class="card-title">Atendimentos Hoje</h4>
                    <a href="{{ route('appointments.index') }}" class="btn btn-primary waves-effect">
                        Ir para lista de atendimentos
                    </a>
                </div>
                
                <div class="table-responsive">
                    <table class="table table-hover table-centered mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th class="py-1 text-center">#</th>
                                <th class="py-1">Nome do Paciente</th>
                                <th class="py-1">Nome do Médico</th>
                                <th class="py-1">Data</th>
                                <th class="py-1">Status</th>
                                <th class="py-1"></th>
                            </tr>
                        </thead>
                        <tbody>
                            @php 
                                $per_page = 10;
                                $currentpage = $appointments->currentPage(); 
                            @endphp
                            @foreach ($appointments as $appointment)
                                <tr>
                                    <td class="text-center">{{ $loop->iteration + $per_page * ($currentpage - 1) }}</td>
                                    <td>
                                        <a href="{{ route('patients.show', $appointment->patient_id) }}"
                                            style="font-weight: 600;"
                                        >
                                            {{ $appointment->patient_name }}
                                        </a>
                                    </td>
                                    <td>{{ $appointment->doctor_name }}</td>
                                    <td>{{ date('d/m/Y H:i:s', strtotime($appointment->created_at)) }}</td>
                                    <td>
                                        <span class="alert
                                            @if ($appointment->status == '0') alert-warning rounded-pill px-2 py-1
                                            @elseif($appointment->status == '1') alert-success rounded-pill px-2 py-1
                                            @else alert-danger rounded-pill px-2 py-1 @endif"
                                        >
                                            @if ($appointment->status == '0')
                                                <span style="font-weight: 600;">Pendente</span>
                                            @elseif($appointment->status == '1')
                                                <span style="font-weight: 600;">Finalizado</span>
                                            @else
                                                <span style="font-weight: 600;">Cancelado</span>
                                            @endif
                                        </span>
                                    </td>
                                    <td>
                                        @if ($appointment->status == '1')
                                            <a href="{{ route('appointments.result.pdf', $appointment->protocol) }}" 
                                                class="text-success" title="Imprimir resultado" target="_blank"
                                            >
                                                <i class="mdi mdi-printer font-size-24 align-middle"></i>
                                            </a>
                                        @else
                                            <span style="color: #d4d4d4">
                                                <i class="mdi mdi-printer font-size-24 align-middle"></i>
                                            </span>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>

                <div class="col-md-12 text-center mt-3" id="paginate">
                    <div class="d-flex justify-content-end">
                        {{ $appointments->links() }}
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div>
